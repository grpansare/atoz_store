import { Component } from '@angular/core';
import { UpdateprofileComponent } from '../homepage/updateprofile/updateprofile.component';
import { MdbModalRef, MdbModalService } from 'mdb-angular-ui-kit/modal';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent {

}
